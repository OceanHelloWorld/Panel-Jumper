﻿using System.Collections;
using System;
using UnityEngine;

public class BodyScript : MonoBehaviour {
    public static Action<string> MonsterHit;
    public MainCharacterFeet FeetScript;

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Monster")
        {
            FeetScript.isJumping = false;
            if(MonsterHit != null)
            {
                MonsterHit("Dead");
            }
        }
    }
}
