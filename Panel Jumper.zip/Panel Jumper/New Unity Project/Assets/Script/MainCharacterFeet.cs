﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainCharacterFeet : MonoBehaviour {
    public GameObject boxDude;
    public Rigidbody2D boxDudeRigid;
    public bool isJumping;
    public int JumpTop;
    public Vector3 toLerp;

    void onTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Platform")
        {
            isJumping = true;
            boxDudeRigid.gravityScale = 0;
            boxDudeRigid.velocity = Vector3.zero;
        }
    }

    void Update ()
    {
        JumpFunction();
    }

    void JumpFunction()
    {
        toLerp = new Vector3(boxDude.transform.position.x, JumpTop, -.5f);
        if(isJumping == true && boxDude.transform.position.y < JumpTop - .5f)
        {
            boxDude.transform.position = Vector3.Lerp(boxDude.transform.position, toLerp, 3 * Time.deltaTime);
        }
        else
        {
            isJumping = false;
            boxDudeRigid.gravityScale = 1;
        }
    }
}
