﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour {
    public GameObject boxDudePrefab;
    public GameObject boxDude;
    public Transform SpawnPosition;

    public bool isGameOver = false;

	// Use this for initialization
	void OnEnable () {
        boxDude = Instantiate(boxDudePrefab, SpawnPosition.position, SpawnPosition.rotation) as GameObject;
		
	}
	
	// Update is called once per frame
	void Update () {
        MovementFunction();
	}

    void MovementFunction()
    {
        if (Input.GetKey(KeyCode.A))
        {
            boxDude.transform.eulerAngles = new Vector2(0, 180);
            boxDude.transform.Translate(Vector2.right * 5f * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.D))
        {
            boxDude.transform.eulerAngles = new Vector2(0, 0);
            boxDude.transform.Translate(Vector2.right * 5f * Time.deltaTime);
        }
    }
}
