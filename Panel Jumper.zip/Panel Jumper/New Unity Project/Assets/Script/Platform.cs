﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platform : MonoBehaviour {
    public BoxCollider2D platformBox;
	// Use this for initialization
	void OnEnable() {
        BodyScript.MonsterHit += MonsterHit;
	}
	
	// Update is called once per frame
	void OnDisable() {
        BodyScript.MonsterHit -= MonsterHit;
    }

    void MonsterHit (string WhatWasSent)
    {
        if(WhatWasSent == "Dead")
        {
            platformBox.enabled = false;
        }
    } 
}
