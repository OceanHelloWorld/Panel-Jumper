﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanelGeneration : MonoBehaviour {

    public GameObject panel;
    public Transform genPoint;
    public float distanceBtwn;

    private float panelSpace;

	// Use this for initialization
	void Start () {
        panelSpace = panel.GetComponent<BoxCollider2D>().size.y;
	}
	
	// Update is called once per frame
	void Update () {
		
        if(transform.position.y < genPoint.position.y)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y + panelSpace + distanceBtwn, transform.position.z);
            Instantiate(panel, transform.position, transform.rotation);
        }
	}
}
