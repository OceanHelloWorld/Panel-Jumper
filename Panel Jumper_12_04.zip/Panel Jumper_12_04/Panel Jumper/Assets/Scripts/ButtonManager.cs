﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonManager : MonoBehaviour
{
    public void NewGameBtn(string newGameLevel)
    {
        Debug.Log("NewGameBtn");
        SceneManager.LoadScene(newGameLevel);
    }

    public void ExitGameBtn()
    {
        Debug.Log("ExitGameBtn");
        Application.Quit();
    }
}
