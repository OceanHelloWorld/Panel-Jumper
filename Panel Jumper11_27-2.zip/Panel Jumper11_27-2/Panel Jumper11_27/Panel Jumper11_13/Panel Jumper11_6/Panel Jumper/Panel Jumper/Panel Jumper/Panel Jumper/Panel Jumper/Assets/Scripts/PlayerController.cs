﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

    private bool facingRight = true;
    public float maxSpeed = 10f;
    public float jumpSpeed = 5f;

    //delay vertical sparation
    //x horizontal 

    Animator anim;

    // Player variables
    public int playerScore = 0;
    public Text scoreText;
    private float gameOver;
    private Rigidbody2D rb;
    private int scoreMulti = 100;

    // Grounded variables
    bool grounded = false;
    public Transform groundCheck;
    float groundRadius = 0.2f;
    public LayerMask whatIsGround;

    public float jumpForce = 1000;

    // Panel variables
    bool onPanel = false;
    public Transform panelCheck;
    float panelRadius = 0.2f;
    public LayerMask whatIsPanel;
    Vector3 wallJumpVector;

    bool doubleJump = false;
    int doubleJumpDelay = 0;
    int doubleJumpDelayMax = 10;

    // Use this for initialization
    void Start () {
        anim = GetComponent<Animator>();
        scoreText.text = "Score: " + playerScore.ToString();
        rb = GetComponent<Rigidbody2D>();
    }
	
	// Update is called once per frame
	void FixedUpdate () {

        Collider2D groundCollider = Physics2D.OverlapCircle(groundCheck.position, groundRadius, whatIsGround);
        grounded = groundCollider != null;

        Collider2D panelCollider = Physics2D.OverlapCircle(panelCheck.position, panelRadius, whatIsPanel);
        onPanel = panelCollider != null;

        //Debug.Log("grounded: " + grounded);
        //Debug.Log("onPanel: " + onPanel);
        //Debug.Log("double Jump: " + doubleJump);


        if (grounded)
        {
            anim.SetBool("Ground", true);
            doubleJump = false;
        }
        else
        {
            anim.SetBool("Ground", false);
        }

        anim.SetFloat("vSpeed", rb.velocity.y);

        float move = Input.GetAxis("Horizontal");

        anim.SetFloat("Speed", Mathf.Abs(move));

        if (!doubleJump)
        {
            rb.velocity = new Vector2(move * maxSpeed, rb.velocity.y);
        }
        else
        {
            if (doubleJumpDelay > 0)
            {
                doubleJumpDelay--;
            }
            else
            {
                doubleJump = false;
            }
        }
        
        if (move > 0 && !facingRight)
        {
            Flip();
        }
        else if (move < 0 && facingRight)
        {
            Flip();
        }

        // Jump when on panel
        if (onPanel)
        {
            rb.velocity = new Vector2(0, rb.velocity.y);
            if (Input.GetKeyDown(KeyCode.Space))
            {
                anim.SetBool("Ground", false);
                //rb.velocity = new Vector2(-10 * maxSpeed, rb.velocity.y * 2);
                //rb.AddForce(new Vector2(-20 * maxSpeed, jumpForce)); 
                //Vector3 dir = (wallJumpVector - rb.transform.position).normalized;
                //Debug.Log(dir);
                wallJumpVector = new Vector3((15 * (facingRight ? -1 : 1)), jumpSpeed, 0);
                rb.velocity = wallJumpVector;
                doubleJump = true;
                doubleJumpDelay = doubleJumpDelayMax;
            }
        }

       
    }

    void Update()
    {
        // Might not need this but it is the double jump
        if((grounded || doubleJump) && Input.GetKeyDown(KeyCode.Space))  // add !doubleJump to enable double jump -- double jump broken
        {
            anim.SetBool("Ground", false);
            rb.AddForce(new Vector2(0, jumpForce));

            if(!doubleJump && !grounded)
            {
                doubleJump = true;
            }
        }

        // Keeping track of the score
        if ((int)(rb.transform.position.y * scoreMulti) > playerScore)
        {
            playerScore = (int)(rb.transform.position.y * scoreMulti);
            scoreText.text = "Score: " + playerScore.ToString();
        }
    }

    // Changes character direction
    void Flip ()
    {
        facingRight = !facingRight;
        /*
         * Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
        */
        transform.RotateAround(GetComponent<Renderer>().bounds.center, new Vector3(0,1,0), 180);
    }
}
